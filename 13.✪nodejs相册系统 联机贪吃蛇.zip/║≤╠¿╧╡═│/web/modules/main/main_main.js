define(function(require, exports, module) {
	require("modules/main/manage_create");
	require("modules/index/tip");
	require("modules/main/manage_upload");
	require("modules/main/manage_show_albums");
	require("modules/main/manage_show_album_imgs");
	require("modules/main/manageRenameModal");
	require("modules/main/setting");
	require("modules/main/nav");
	require("modules/main/chat");
	require("modules/main/face");
	require("modules/main/mode");
});