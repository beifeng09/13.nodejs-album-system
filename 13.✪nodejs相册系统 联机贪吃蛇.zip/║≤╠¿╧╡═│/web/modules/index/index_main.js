define(function(require, exports, module) {
	require("modules/index/login.js");
	require("modules/index/regist.js");
	require("modules/index/tip.js");
});